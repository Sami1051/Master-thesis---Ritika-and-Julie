# Mini CCS Thesis

This repository contains code, notebooks, and outputs for our master's thesis.

## Structure
- data/raw: original data
- data/processed: cleaned data
- notebooks: exploratory analysis
- src: reusable Python scripts
- outputs/figures: plots
- outputs/tables: exported tables