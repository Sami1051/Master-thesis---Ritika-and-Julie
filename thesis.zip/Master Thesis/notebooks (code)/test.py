print("Setup works")

import math
print(math.sqrt(16))