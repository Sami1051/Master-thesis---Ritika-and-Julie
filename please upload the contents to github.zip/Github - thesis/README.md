# Mini CCS Thesis

This repository contains data, notebooks, outputs and appendix for our master's thesis.

## Structure
- appendix
- data/processed: cleaned data
- model: code used
- outputs